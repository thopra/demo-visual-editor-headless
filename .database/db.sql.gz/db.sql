-- MariaDB dump 10.19  Distrib 10.11.16-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.16-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1774688506,1774688506,0,0,0,0,1,'{\"7835fab54cd922ae4038d51bb1bba0dc0e2999f7\":{\"identifier\":\"t3information\"},\"77061e9fbddb4bb8ae60eb2eeaf6a6aa74b2bc71\":{\"identifier\":\"docGettingStarted\"}}','a6cef095ff932779feaa1980cdf4132775bdf675','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('0ae7b2b9dbb334ed1dcbf44996c75560f6c64b132685e8dbc1312c3feeab965e','[DISABLED]',1,1774947172,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"c3de581c1b377ddc7d4c32dc3fb6fc01912deefe04b5a8feca06673b5e88a5c6\";}'),
('6b04ef3119fbe60f6038bbf64ba8975090eb653045e394130b0d28e03845c341','[DISABLED]',1,1774954472,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"c1f0cb2cb5a1582906f43fd66ace3db2bf0ff600a149a5b1723b44ade80b1d0e\";}'),
('6efcd01d4d929b23bc30e2d5654b75bacdbda75fb976585e76bfc33fa289268e','[DISABLED]',1,1774959665,'a:3:{s:26:\"formProtectionSessionToken\";s:64:\"5b9282f41b5825763bf91e4ae057e837c8484ceae0eca7c1696c5abf3293182b\";s:23:\"backend.sudo-mode.claim\";s:2:\"[]\";s:23:\"backend.sudo-mode.grant\";s:293:\"{\"route:\\/module\\/system\\/maintenance\":{\"subject\":{\"class\":\"TYPO3\\\\CMS\\\\Backend\\\\Security\\\\SudoMode\\\\Access\\\\RouteAccessSubject\",\"identity\":\"route:\\/module\\/system\\/maintenance\",\"subject\":\"\\/module\\/system\\/maintenance\",\"lifetime\":\"medium\",\"group\":\"systemMaintainer\"},\"expiration\":1774956294}}\";}'),
('a0f16ef0ebb3cd8474de280a53c8be019aaed4ffa06726e7ad4cd773e67dcbd0','[DISABLED]',1,1774954464,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"7de23051517dd29b21a1c9a5d9c77946f526bd8f95e96b65cca5b6dcecad0856\";}'),
('d7ca40fcad623c0816f7c2f265baca3c6abdea154c7d06c88272c78eebe50426','[DISABLED]',1,1774954488,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"e67fd16f5e4b54cb255cb96871443276b4dca2206dfb782a9510180f2f631638\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `tsconfig_includes` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1774688297,1774688297,0,0,0,0,NULL,'default','a:7:{s:10:\"moduleData\";a:11:{s:28:\"dashboard/current_dashboard/\";s:40:\"a6cef095ff932779feaa1980cdf4132775bdf675\";s:10:\"web_layout\";a:3:{s:8:\"viewMode\";i:1;s:10:\"showHidden\";b:1;s:9:\"languages\";a:1:{i:0;i:0;}}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:6:\"web_ts\";a:1:{s:6:\"action\";s:17:\"typoscript_active\";}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:18:\"pagetsconfig_pages\";}s:7:\"records\";a:4:{s:9:\"clipBoard\";b:1;s:9:\"searchBox\";b:0;s:15:\"collapsedTables\";a:0:{}s:9:\"languages\";a:1:{i:0;i:0;}}s:8:\"web_edit\";a:3:{s:8:\"function\";i:1;s:9:\"languages\";a:1:{i:0;s:1:\"0\";}s:10:\"showHidden\";b:1;}s:17:\"typoscript_active\";a:7:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:3:{i:0;i:0;i:1;i:1;i:2;s:40:\"93525f9d1e84d19a4d3ca5272e72630eec8bbe77\";}s:9:\"languages\";a:1:{i:0;i:0;}}s:10:\"system_log\";a:1:{s:10:\"constraint\";s:334:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:0:\"\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:23:\"backend_user_management\";a:0:{}s:13:\"system_config\";a:1:{s:4:\"tree\";s:20:\"httpMiddlewareStacks\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:11:{s:28:\"dashboard/current_dashboard/\";s:40:\"d101187ae113b9ea8b63eb8226651ebd734d86da\";s:10:\"web_layout\";s:40:\"2d8fb598e7371e7ccc29987465301f323dbba84d\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"2d8fb598e7371e7ccc29987465301f323dbba84d\";s:6:\"web_ts\";s:40:\"d101187ae113b9ea8b63eb8226651ebd734d86da\";s:12:\"pagetsconfig\";s:40:\"d101187ae113b9ea8b63eb8226651ebd734d86da\";s:7:\"records\";s:40:\"2d8fb598e7371e7ccc29987465301f323dbba84d\";s:8:\"web_edit\";s:40:\"2d8fb598e7371e7ccc29987465301f323dbba84d\";s:17:\"typoscript_active\";s:40:\"2130beb706a2ea2bbcac81e29e82d28ad52d16ed\";s:10:\"system_log\";s:40:\"28afee8a83e3c90f191e1e818e3b8b2da476669a\";s:23:\"backend_user_management\";s:40:\"28afee8a83e3c90f191e1e818e3b8b2da476669a\";s:13:\"system_config\";s:40:\"28afee8a83e3c90f191e1e818e3b8b2da476669a\";}s:13:\"pageLanguages\";a:2:{i:2;a:1:{i:0;i:0;}i:1;a:1:{i:0;i:0;}}s:6:\"resize\";a:1:{s:7:\"backend\";a:1:{s:10:\"navigation\";s:3:\"308\";}}}',0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$ZklXY25FY0ZrRWxrU3RxQg$gNSZZtCCUP0ucOhpgBWgraI5FQ2U4Yo64erG3ZeTjJM','',0,NULL,'','tpb@onm.de','',1,3,NULL,1,NULL,'',NULL,1774954533,NULL,'\"{\\\"emailMeAtLogin\\\":0,\\\"titleLen\\\":50,\\\"edit_docModuleUpload\\\":\\\"1\\\"}\"',''),
(2,0,1774689389,1774689389,0,0,0,0,NULL,'default',NULL,0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$bkVGVEhoSXBJY2paTmVPQw$KVoqI2eHMoUCDb5rHk+iWJjFB47ohlanRvfQhmx1qJQ','',0,NULL,'','','',1,3,NULL,1,NULL,'',NULL,0,NULL,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(4,'2__0_0_0_0',1777551499,'x�mTMs�0�/��\r!�s�$���Ʌ�ГFHk�Aֺ�`2��]ٖ����{�[�(?U�?�r�,?]9/�N��A������r��/3�<o�\0����j�X����{��,�L�i���L�eFY�����Q�\"�2���;*��,�G��+SG���,��	�Z��\n�	@*�Q�\'W�ŝ�����u�a���ܰ�[0�v�Y1uW���B�b1bRUUt����ry�~�gxFt�m��!K�y���%�<\r��\'�g|q�ڧ-�Ӕ�L����q���������$�u>�É\0�#�D�S\ZOf�ņ%j�-5ؑ!�\n���jZ8���S���C�[�ZEV��?�X$�����7��I���l��]=\n�g6t���^+U���Z�-\0�mJ� �j�\0\\�% ���	/Ǉ#M/�p�m[��%��������J/�u�k�p�����������3w��\r�+����+=�:S��p���d�u:n�\0�n�.�E�\Z�b�Z����帽a�u�r���䝧��L�2�B�`2�\r=�jʱ ��\'A��1��p`�]s���a��x��\\�Z9w�,H�H���\'�(�����\r�yq�Ƀi:7.㟆���p�J�2Bw�(q�ߊ\n�_�1��\n���4��|`bGo&T����R0h���]I����)B��i�U3�i���<qu�i}�ݤKo���6����yd~\r�~�Lc�����|PKX'),
(7,'1__0_0_1_1',1777551659,'x�mT�r�0�}@+���)�t�C\'���84	�S�JR�=��{AI�i;7i�X삼,�OU揼\\��OW�ˬS2{Te�����_Ne��MۇW���z=�,����{����L�i���L6eFU������102E�eV�-vt����<Z�L�E�Y<��V�^!]�6\0��Fq�R�wvLsSw��]�t�.r�Zn��;�ag��]�G��S����b��@��?�2L��#xt�M�X����3�l�X��^T,��Ǘ��@@��X>ɿ�ˈ�}ޡ<O�(���e����ϯOo?�D+l���b5�����|*�@�i���ذ�m4�;\n$XAr�SM���Uu�XPSyhx�Z�(���`���r4�ă?����=yB�|�M�t��G�}φ�߷�k��Q�0�}˼ �M��VM�g	��k~�k�p\"���ݮ%-]B��6u7�X0mP����&�e��`DK+sH������m�^��4p�m��S���J쁅�LI�S��)��\0�n�>�M�\Z�\"q���t�x��r��0�9o��@,y�`�iAF^����#�o&�Ʊ�~2�,��i�ݭ&�X&��Gh�Ł�eQsW΂eHd�{�2�\r_��0�����!{0M�c����ayb�~?��R��Н�I���BʗpJ퇬B��8�Z_L��̈́���t��`�F	�ٍ��0�wW�#�4����l\Z�?*OZ�W�\\bw�҃wEg���V��<1��D?p���)�߿��Kb'),
(8,'2__0_0_1_1',1777551661,'x�mTMs�0�/��\r!�s�$���Ʌ�ГFHk�Aֺ�`2��]ٖ����{�[�(?U�?�r�,?]9/�N��A������r��/3�<o�\0����j�X����{��,�L�i���L�eFY�����Q�\"�2���;*��,�G��+SG���,��	�Z��\n�	@*�Q�\'W�ŝ�����u�a���ܰ�[0�v�Y1uW���B�b1bRUUt����ry�~�gxFt�m��!K�y���%�<\r��\'�g|q�ڧ-�Ӕ�L����q���������$�u>�É\0�#�D�S\ZOf�ņ%j�-5ؑ!�\n���jZ8���S���C�[�ZEV��?�X$�����7��I���l��]=\n�g6t���^+U���Z�-\0�mJ� �j�\0\\�% ���	/Ǉ#M/�p�m[��%��������J/�u�k�p�����������3w��\r�+����+=�:S��p���d�u:n�\0�n�.�E�\Z�b�Z����帽a�u�r���䝧��L�2�B�`2�\r=�jʱ ��\'A��1��p`�]s���a��x��\\�Z9w�,H�H���\'�(�����\r�yq�Ƀi:7.㟆���p�J�2Bw�(q�ߊ\n�_�1��\n���4��|`bGo&T����R0h���]I����)B��i�U3�i���<qu�i}�ݤKo���6����yd~\r�~�Lc�����|PKX');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(5,'2__0_0_0_0','pageId_2'),
(9,'1__0_0_1_1','pageId_1'),
(10,'2__0_0_1_1','pageId_2');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_logo` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1774688395,1774688395,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,1,31,31,1,1774959447,0,0,0,0,0.5,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__CaminoStartpage','pagets__CaminoContentpage','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(2,0,1774689559,1774689559,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,1,31,31,1,1774690231,0,0,0,0,0.5,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__CaminoStartpage','pagets__CaminoContentpage','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(3,1,1774959581,1774689731,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1774689743,0,0,0,0,0.5,1,'Test','/test',NULL,0,0,0,0,'Test',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1774688467,1774688467,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1774689731,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/test\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Test\",\"nav_title\":\"Test\",\"nav_hide\":\"0\",\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\",\"crdate\":1774689731,\"t3ver_stage\":0,\"tstamp\":1774689731,\"uid\":3}',0,'0400$02fbdb73ede4f29507a7220ae311852d:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(2,1774689736,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$a4add5c7ac764bca8b06ad10028c5eae:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(3,1774689743,1,'BE',1,0,3,'tt_content','{\"CType\":\"textpic\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"0\",\"imagecols\":\"2\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"Test\",\"header_link\":\"\",\"subheader\":\"Test\",\"bodytext\":\"<p>Test<\\/p>\",\"imageborder\":\"0\",\"image_zoom\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\"}\",\"crdate\":1774689743,\"t3ver_stage\":0,\"tstamp\":1774689743,\"uid\":3}',0,'0400$2b825383ab52fa0beddf854da9797a0e:b92300cfb5d1d3645c9cb212a7f56c1f'),
(4,1774690178,1,'BE',1,0,4,'tt_content','{\"CType\":\"camino_hero\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":2,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"Test\",\"subheader\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_config\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1774690178,\"t3ver_stage\":0,\"tstamp\":1774690178,\"uid\":4}',0,'0400$9713bdef54713d75253ddd41718c10fb:4d391f5ef79b8d5d10dffa8a07ca167d'),
(5,1774690231,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"header\":\"Welcome to your default website\",\"bodytext\":\"This website is made with <a href=\\\"https:\\/\\/typo3.org\\\" target=\\\"_blank\\\" rel=\\\"noreferrer\\\">TYPO3<\\/a>  and the Camino Theme.<\\/p>\",\"tx_themecamino_link_config\":\"\",\"fe_group\":\"0\",\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Welcome to your default website test\",\"bodytext\":\"<p>This website is made with <a href=\\\"https:\\/\\/typo3.org\\\" target=\\\"_blank\\\" rel=\\\"noreferrer\\\">TYPO3<\\/a> and the Camino Theme.<\\/p>\\r\\n\\r\\n\",\"tx_themecamino_link_config\":\"0\",\"fe_group\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"}}',0,'0400$8c2ba9c57ef9e8ec315a8d27a084ab2d:01dbc21fdb1263685b9147b3b1596ea8'),
(6,1774816817,1,'BE',1,0,5,'tt_content','{\"CType\":\"header\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\"}\",\"crdate\":1774816817,\"t3ver_stage\":0,\"tstamp\":1774816817,\"uid\":5}',0,'0400$6dad11b7a2806d24ad20f2d815ba9941:c7626fc9bcba6f70beb6ebc085a400db'),
(7,1774816822,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"header\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"TEst\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$1a13cc337ee556a473bb885b9a23e400:c7626fc9bcba6f70beb6ebc085a400db'),
(8,1774826358,1,'BE',1,0,6,'tt_content','{\"CType\":\"header\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":128,\"sys_language_uid\":0,\"header\":\"Test 2\",\"header_link\":\"\",\"subheader\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\"}\",\"crdate\":1774826358,\"t3ver_stage\":0,\"tstamp\":1774826358,\"uid\":6}',0,'0400$26e9dd63daf60425443aa7649df9518d:c0db6803ab1ec5f70c36e2a72187867b'),
(9,1774959423,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"header\":\"Test 2\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Content ELement Header Only\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$571fd4f5640d2fb563bde2edb6aa6e52:c0db6803ab1ec5f70c36e2a72187867b'),
(10,1774959426,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"header\":\"Content ELement Header Only\"},\"newRecord\":{\"header\":\"Content Element Header Only\"}}',0,'0400$7568c6226ac9a4149ed23493f157d4ea:c0db6803ab1ec5f70c36e2a72187867b'),
(11,1774959435,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"CType\":\"header\"},\"newRecord\":{\"CType\":\"text\"}}',0,'0400$087cb2b1ba6200c0aef404cdec4a1ed8:c7626fc9bcba6f70beb6ebc085a400db'),
(12,1774959447,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"header\":\"TEst\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Content Element Text\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$3eb299b0b26022b1cbcc6ddf4f753889:c7626fc9bcba6f70beb6ebc085a400db'),
(13,1774959581,4,'BE',1,0,3,'tt_content',NULL,0,'0400$56609cf49b00befbc4856a3b97c913f2:b92300cfb5d1d3645c9cb212a7f56c1f'),
(14,1774959581,4,'BE',1,0,3,'pages',NULL,0,'0400$56609cf49b00befbc4856a3b97c913f2:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(15,1774959659,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"bodytext\":\"This website is made with <a href=\\\"https:\\/\\/typo3.org\\\" target=\\\"_blank\\\" rel=\\\"noreferrer\\\">TYPO3<\\/a>  and the Camino Theme.<\\/p>\",\"fe_group\":\"0\",\"l18n_diffsource\":null},\"newRecord\":{\"bodytext\":\"<p>This website is made with <a href=\\\"https:\\/\\/typo3.org\\\" target=\\\"_blank\\\" rel=\\\"noreferrer\\\">TYPO3<\\/a> and headless.<\\/p>\\r\\n\\r\\n\",\"fe_group\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$8b109c0c3567abba35307a71541c84c7:7fa2c035f26826fe83eeecaaeddc4d40');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=447 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1774688494,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','172.18.0.5','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1774688505,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','172.18.0.5','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(3,1774689326,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.sys_be_shortcuts_group\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 51. Requested URL: https://typo3.ddev.site/typo3/main?token=--AnonymizedToken--6c5c44ec18f3d09aa11a41a9&redirect=web_layout&redirectParams=id%%3D1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(4,1774689559,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.sys_be_shortcuts_group\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 51. Requested URL: https://typo3.ddev.site/typo3/main?token=--AnonymizedToken--6c5c44ec18f3d09aa11a41a9',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(5,1774689625,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1639828178: TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception in /var/www/html/vendor/typo3/cms-backend/Resources/Private/Templates/Backend/Main.fluid.html: TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception in /var/www/html/vendor/typo3/cms-backend/Resources/Private/Partials/Backend/Topbar.fluid.html: TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception in /var/www/html/vendor/typo3/cms-backend/Resources/Private/Partials/Backend/Topbar.fluid.html: TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception in /var/www/html/vendor/typo3/cms-backend/Resources/Private/Partials/Backend/Topbar.fluid.html: TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception in /var/www/html/vendor/typo3/cms-backend/Resources/Private/Partials/Backend/Topbar.fluid.html: TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception in /var/www/html/vendor/typo3/cms-backend/Resources/Private/Templates/ToolbarItems/BookmarkToolbarItemItem.fluid.html: ViewHelper f:translate in non-extbase context needs attribute \"domain\" or \"extensionName\" to resolve key=\"core.bookmarks:title\" without path. Either set attribute \"domain\" or \"extensionName\" together with the short key \"yourKey\" to result or (better) use a full LLL reference like key=\"LLL:your_extension.name:yourKey\". Alternatively, you can also define a default value. (/var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/TranslateViewHelper.php:134) (/var/www/html/vendor/typo3fluid/fluid/src/Core/ErrorHandler/StandardErrorHandler.php:35) (/var/www/html/vendor/typo3fluid/fluid/src/Core/ErrorHandler/StandardErrorHandler.php:35) (/var/www/html/vendor/typo3fluid/fluid/src/Core/ErrorHandler/StandardErrorHandler.php:35) (/var/www/html/vendor/typo3fluid/fluid/src/Core/ErrorHandler/StandardErrorHandler.php:35) (/var/www/html/vendor/typo3fluid/fluid/src/Core/ErrorHandler/StandardErrorHandler.php:35) | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/ErrorHandler/StandardErrorHandler.php in line 35. Requested URL: https://typo3.ddev.site/typo3/main?token=--AnonymizedToken--6c5c44ec18f3d09aa11a41a9&redirect=web_layout&redirectParams=id%%3D1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(6,1774689731,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(7,1774689736,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"2\"}',1,0,'',0,'','info',NULL,NULL),
(8,1774689743,1,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(9,1774690134,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(10,1774690178,1,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(11,1774690231,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"5\"}',2,0,'',0,'','info',NULL,NULL),
(12,1774691145,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(13,1774691429,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site api depends on unavailable sets: typo3/headless | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://typo3-api.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(14,1774691461,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site api depends on unavailable sets: typo3/headless | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://typo3-api.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(15,1774691467,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(16,1774699610,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(17,1774699875,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(18,1774700065,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(19,1774700088,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(20,1774700229,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(21,1774700233,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user','172.18.0.5','[\"admin\"]',-1,0,'',0,'','info',NULL,NULL),
(22,1774700240,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(23,1774700250,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(24,1774700258,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(25,1774700272,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(26,1774700701,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(27,1774700899,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(28,1774700958,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(29,1774701015,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(30,1774702615,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(31,1774703191,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(32,1774703797,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Undefined constant TYPO3\\CMS\\VisualEditor\\Service\\EditModeService::isEditMode | Error thrown in file /var/www/html/vendor/friendsoftypo3/headless/Configuration/Services.php in line 58. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(33,1774706849,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Cannot autowire service \"FriendsOfTYPO3\\Headless\\Service\\VisualEditingService\": argument \"$request\" of method \"__construct()\" references interface \"Psr\\Http\\Message\\ServerRequestInterface\" but no such service exists. You should maybe alias this interface to one of these existing services: \"TYPO3\\CMS\\Core\\Http\\ServerRequest\", \"TYPO3\\CMS\\Extbase\\Mvc\\Request\". | Symfony\\Component\\DependencyInjection\\Exception\\RuntimeException thrown in file /var/www/html/vendor/symfony/dependency-injection/Compiler/DefinitionErrorExceptionPass.php in line 48. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(34,1774706857,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Cannot autowire service \"FriendsOfTYPO3\\Headless\\Service\\VisualEditingService\": argument \"$request\" of method \"__construct()\" references interface \"Psr\\Http\\Message\\ServerRequestInterface\" but no such service exists. You should maybe alias this interface to one of these existing services: \"TYPO3\\CMS\\Core\\Http\\ServerRequest\", \"TYPO3\\CMS\\Extbase\\Mvc\\Request\". | Symfony\\Component\\DependencyInjection\\Exception\\RuntimeException thrown in file /var/www/html/vendor/symfony/dependency-injection/Compiler/DefinitionErrorExceptionPass.php in line 48. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(35,1774709845,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(36,1774709919,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(37,1774709973,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(38,1774710139,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(39,1774710175,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 41',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(40,1774710175,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 41',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(41,1774710400,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 41',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(42,1774710400,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 41',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(43,1774710441,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 41',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(44,1774710441,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 41',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(45,1774710786,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 39',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(46,1774710790,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(47,1774710791,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 39',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(48,1774710810,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$resourceFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 39',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(49,1774711008,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 42',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(50,1774711119,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 42',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(51,1774711119,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 42',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(52,1774711155,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 42',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(53,1774713903,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected token \"return\" | ParseError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php in line 56. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(54,1774713912,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected token \"return\" | ParseError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php in line 56. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(55,1774713973,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Cannot autowire service \"TYPO3\\CMS\\Core\\Page\\JavaScriptRenderer\": argument \"$handlerResource\" of method \"__construct()\" is type-hinted \"string\", you should configure its value explicitly. | Symfony\\Component\\DependencyInjection\\Exception\\RuntimeException thrown in file /var/www/html/vendor/symfony/dependency-injection/Compiler/DefinitionErrorExceptionPass.php in line 48. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(56,1774713977,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Cannot autowire service \"TYPO3\\CMS\\Core\\Page\\JavaScriptRenderer\": argument \"$handlerResource\" of method \"__construct()\" is type-hinted \"string\", you should configure its value explicitly. | Symfony\\Component\\DependencyInjection\\Exception\\RuntimeException thrown in file /var/www/html/vendor/symfony/dependency-injection/Compiler/DefinitionErrorExceptionPass.php in line 48. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(57,1774714647,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 47',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(58,1774714647,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $pageRenderer in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 57',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(59,1774714647,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 47',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(60,1774714647,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $pageRenderer in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 57',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(61,1774714680,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 47',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(62,1774714680,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 47',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(63,1774715665,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(64,1774715674,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(65,1774715680,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(66,1774715687,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(67,1774715695,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(68,1774715703,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(69,1774715718,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(70,1774715743,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(71,1774715746,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(72,1774715753,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(73,1774715797,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(74,1774716012,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(75,1774716044,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(76,1774717395,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(77,1774717395,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(78,1774717531,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(79,1774717531,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 51',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(80,1774717531,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(81,1774717531,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 51',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(82,1774719140,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(83,1774719140,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(84,1774719289,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(85,1774719289,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(86,1774719289,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(87,1774719289,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(88,1774719289,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(89,1774719289,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(90,1774719326,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(91,1774719326,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(92,1774719326,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(93,1774719326,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 44',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(94,1774719326,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(95,1774719326,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $options in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 56',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(96,1774720820,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(97,1774720843,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(98,1774720902,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"stdWrap.\" in /var/www/html/vendor/friendsoftypo3/headless/Classes/ContentObject/JsonContentObject.php line 76',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(99,1774722113,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(100,1774722145,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(101,1774722179,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(102,1774725402,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Expected to find class \"FriendsOfTYPO3\\Headless\\DataProcessing\\VisualEditingRecordInformation\" in file \"/var/www/html/vendor/friendsoftypo3/headless/Classes/DataProcessing/VisualEditingRecordInformation.php\" while importing services from resource \"../Classes/*\", but it was not found! Check the namespace prefix used with the resource. | Symfony\\Component\\DependencyInjection\\Exception\\InvalidArgumentException thrown in file /var/www/html/vendor/symfony/dependency-injection/Loader/FileLoader.php in line 369. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(103,1774725658,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(104,1774725677,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(105,1774725792,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(106,1774725873,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(107,1774725939,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(108,1774726034,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(109,1774726047,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(110,1774726283,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(111,1774726294,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: The definition for \"VisualEditingRecordInformationProcessor\" has no class. If you intend to inject this service dynamically at runtime, please mark it as synthetic=true. If this is an abstract definition solely used by child definitions, please add abstract=true, otherwise specify a class to get rid of this error. | Symfony\\Component\\DependencyInjection\\Exception\\RuntimeException thrown in file /var/www/html/vendor/symfony/dependency-injection/Compiler/CheckDefinitionValidityPass.php in line 63. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(112,1774726500,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(113,1774726534,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(114,1774726570,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(115,1774726608,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(116,1774726629,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(117,1774726694,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'',0,'','info',NULL,NULL),
(118,1774745614,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: syntax error, unexpected identifier \"richtextOptionsAndProcessingCo...\", expecting variable | ParseError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/Field.php in line 34. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(119,1774745942,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $schema in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 71',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(120,1774745942,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $schema in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 71',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(121,1774746200,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$fieldFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 81',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(122,1774746200,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$fieldFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 81',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(123,1774746253,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$fieldFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 81',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(124,1774746253,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Service\\VisualEditingService::$fieldFactory in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 81',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(125,1774746778,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $table in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 105',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(126,1774746778,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $data in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 105',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(127,1774746778,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $table in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 105',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(128,1774746778,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $data in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 105',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(129,1774746863,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $data in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 109',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(130,1774746863,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $data in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 109',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(131,1774747964,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $thtis in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/Field.php line 78',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(132,1774747964,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Attempt to read property \"fieldSchema\" on null in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/Field.php line 78',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(133,1774747964,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $thtis in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/Field.php line 78',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(134,1774747964,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Attempt to read property \"fieldSchema\" on null in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/Field.php line 78',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(135,1774748129,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $value in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/Field.php line 81',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(136,1774748129,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $value in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/Field.php line 81',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(137,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(138,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(139,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(140,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(141,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(142,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(143,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(144,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(145,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(146,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(147,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(148,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(149,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(150,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(151,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(152,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(153,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(154,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(155,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(156,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(157,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(158,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(159,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(160,1774748510,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $field in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Form/FieldFactory.php line 24',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(161,1774751003,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(162,1774751114,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"api\"]',-1,0,'',0,'','info',NULL,NULL),
(163,1774751142,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(164,1774752025,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: FriendsOfTYPO3\\Headless\\Utility\\UrlUtility::getFrontendUrlWithSite(): Return value must be of type string, TYPO3\\CMS\\Core\\Http\\Uri returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Utility/UrlUtility.php in line 85. Requested URL: https://api.typo3.ddev.site/typo3/module/web/edit?token=--AnonymizedToken--247d8faf0d0313904144a080&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(165,1774752238,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Class \"TYPO3\\CMS\\VisualEditor\\Backend\\Controller\\Uri\" not found | Error thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Backend/Controller/PageEditController.php in line 215. Requested URL: https://api.typo3.ddev.site/typo3/module/web/edit?token=--AnonymizedToken--247d8faf0d0313904144a080&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(166,1774752271,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to undefined method TYPO3\\CMS\\VisualEditor\\Backend\\Controller\\PageEditController::sanitizeBaseUrl() | Error thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Backend/Controller/PageEditController.php in line 216. Requested URL: https://api.typo3.ddev.site/typo3/module/web/edit?token=--AnonymizedToken--247d8faf0d0313904144a080&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(167,1774753278,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined variable $site in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Backend/Controller/PageEditController.php line 218',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(168,1774753278,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined variable $language in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Backend/Controller/PageEditController.php line 218',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(169,1774753278,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: FriendsOfTYPO3\\Headless\\Utility\\HeadlessMode::overrideBackendRequestBySite(): Argument #1 ($site) must be of type TYPO3\\CMS\\Core\\Site\\Entity\\SiteInterface, null given, called in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Backend/Controller/PageEditController.php on line 218 | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Utility/HeadlessMode.php in line 49. Requested URL: https://api.typo3.ddev.site/typo3/module/web/edit?token=--AnonymizedToken--247d8faf0d0313904144a080&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(170,1774753582,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined variable $html in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Backend/Controller/PageEditController.php line 249',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(171,1774753582,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Core\\Http\\HtmlResponse::__construct(): Argument #1 ($content) must be of type string, null given, called in /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Backend/Controller/PageEditController.php on line 249 | TypeError thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/HtmlResponse.php in line 36. Requested URL: https://api.typo3.ddev.site/typo3/module/web/edit?token=--AnonymizedToken--247d8faf0d0313904144a080&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(172,1774756610,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(173,1774757538,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(174,1774757541,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(175,1774757558,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(176,1774757562,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(177,1774757571,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(178,1774757585,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(179,1774757623,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(180,1774757958,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(181,1774759448,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(182,1774759448,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(183,1774759450,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(184,1774759450,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(185,1774759490,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(186,1774759490,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(187,1774759572,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(188,1774759572,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(189,1774759575,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(190,1774759575,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(191,1774759579,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(192,1774759580,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(193,1774759580,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(194,1774759580,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(195,1774759580,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(196,1774759580,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(197,1774759590,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(198,1774759590,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(199,1774759726,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(200,1774759726,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(201,1774759730,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(202,1774759730,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(203,1774759733,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(204,1774759733,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(205,1774759742,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(206,1774759742,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(207,1774759841,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(208,1774759841,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(209,1774759844,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(210,1774759844,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(211,1774759865,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(212,1774759865,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(213,1774759865,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(214,1774759865,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(215,1774759865,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(216,1774759865,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(217,1774759940,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(218,1774759940,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(219,1774759940,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(220,1774759941,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(221,1774759941,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(222,1774759941,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(223,1774759965,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\VisualEditor\\Middleware\\PersistenceMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 60. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(224,1774780756,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(225,1774780843,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(226,1774780843,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(227,1774780843,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(228,1774780843,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(229,1774784429,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(230,1774785025,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(231,1774785025,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(232,1774785025,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(233,1774785025,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(234,1774785042,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(235,1774785042,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(236,1774785042,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(237,1774785042,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(238,1774785213,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(239,1774785215,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(240,1774785215,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(241,1774785215,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(242,1774785215,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(243,1774785252,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(244,1774785252,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(245,1774785252,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(246,1774785252,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(247,1774785367,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(248,1774785367,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(249,1774785367,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(250,1774785367,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(251,1774785900,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(252,1774785900,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(253,1774785900,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(254,1774785900,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(255,1774786438,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(256,1774786438,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(257,1774786438,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(258,1774786438,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(259,1774786441,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(260,1774786441,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(261,1774786441,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(262,1774786441,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(263,1774786452,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(264,1774786452,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(265,1774786452,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(266,1774786452,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(267,1774786883,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(268,1774786883,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(269,1774786883,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(270,1774786883,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(271,1774786884,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(272,1774786884,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(273,1774786884,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(274,1774786884,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(275,1774786916,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(276,1774786916,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(277,1774786916,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(278,1774786917,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(279,1774786917,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(280,1774786917,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(281,1774786917,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(282,1774786917,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(283,1774786954,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(284,1774786954,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(285,1774786954,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(286,1774786954,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(287,1774787014,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(288,1774787014,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(289,1774787014,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(290,1774787014,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(291,1774787016,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(292,1774787016,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(293,1774787016,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(294,1774787016,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(295,1774787030,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(296,1774787030,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(297,1774787030,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(298,1774787030,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(299,1774787031,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(300,1774787031,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(301,1774787031,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(302,1774787031,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/vendor/friendsoftypo3/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(303,1774790667,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(304,1774790667,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(305,1774790667,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(306,1774790667,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(307,1774790671,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(308,1774790671,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(309,1774790672,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(310,1774790672,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(311,1774790686,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(312,1774790686,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(313,1774790686,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(314,1774790686,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(315,1774790766,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(316,1774790766,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(317,1774790766,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(318,1774790766,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(319,1774790775,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(320,1774790775,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(321,1774790775,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(322,1774790775,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1436717267: Invalid header value for header \"Access-Control-Allow-Origin\". The header value must be a string or array of strings | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Http/Message.php in line 244. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(323,1774790850,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: FriendsOfTYPO3\\Headless\\Middleware\\CorsMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Middleware/CorsMiddleware.php in line 61. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(324,1774790850,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: FriendsOfTYPO3\\Headless\\Middleware\\CorsMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Middleware/CorsMiddleware.php in line 61. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(325,1774790850,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: FriendsOfTYPO3\\Headless\\Middleware\\CorsMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Middleware/CorsMiddleware.php in line 61. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(326,1774790851,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: FriendsOfTYPO3\\Headless\\Middleware\\CorsMiddleware::process(): Return value must be of type Psr\\Http\\Message\\ResponseInterface, none returned | TypeError thrown in file /var/www/html/vendor/friendsoftypo3/headless/Classes/Middleware/CorsMiddleware.php in line 61. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(327,1774804232,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $importmap in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 156',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(328,1774804232,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined variable $importmap in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 156',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(329,1774814307,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Expected to find class \"FriendsOfTYPO3\\Headless\\DataProcessing\\JavaScriptRendererProcessor\" in file \"/var/www/html/vendor/friendsoftypo3/headless/Classes/DataProcessing/JavaScriptRendererProcessor.php\" while importing services from resource \"../Classes/*\", but it was not found! Check the namespace prefix used with the resource. | Symfony\\Component\\DependencyInjection\\Exception\\InvalidArgumentException thrown in file /var/www/html/vendor/symfony/dependency-injection/Loader/FileLoader.php in line 369. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(330,1774814318,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Expected to find class \"FriendsOfTYPO3\\Headless\\DataProcessing\\JavaScriptRendererProcessor\" in file \"/var/www/html/vendor/friendsoftypo3/headless/Classes/DataProcessing/JavaScriptRendererProcessor.php\" while importing services from resource \"../Classes/*\", but it was not found! Check the namespace prefix used with the resource. | Symfony\\Component\\DependencyInjection\\Exception\\InvalidArgumentException thrown in file /var/www/html/vendor/symfony/dependency-injection/Loader/FileLoader.php in line 369. Requested URL: https://api.typo3.ddev.site/?__typo3_install=&install%%5Bcontroller%%5D=maintenance&install%%5Bcontext%%5D=backend&install%%5Btheme%%5D=auto&install%%5Baction%%5D=cacheClearAll',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(331,1774816817,1,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(332,1774816822,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"7\"}',1,0,'',0,'','info',NULL,NULL),
(333,1774820820,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(334,1774820820,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(335,1774820820,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(336,1774820820,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(337,1774820821,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(338,1774820821,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(339,1774820824,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(340,1774820824,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(341,1774820824,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(342,1774820824,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(343,1774820825,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(344,1774820825,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1728220800: JavaScript module \"EXT:rte_ckeditor/Resources/Public/Contrib/translations/en.js\" could not be resolved. (Missing entry in Configuration/JavaScriptModules.php?). | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptRenderer.php in line 118. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(345,1774821163,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"allowedOrigins\" in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 67',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(346,1774821163,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"allowedOrigins\" in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 67',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(347,1774824809,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"allowedOrigins\" in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 70',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(348,1774824809,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"allowedOrigins\" in /var/www/html/vendor/friendsoftypo3/headless/Classes/Service/VisualEditingService.php line 70',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(349,1774826358,1,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(350,1774829854,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(351,1774829854,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(352,1774829854,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(353,1774829854,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(354,1774829854,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(355,1774829854,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(356,1774894851,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(357,1774899138,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: FriendsOfTYPO3\\Headless\\Middleware\\PageRendererJavaScriptResponseMiddleware::$headlessMode in /var/www/html/packages/headless/Classes/Middleware/PageRendererJavaScriptResponseMiddleware.php line 57',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL),
(358,1774899138,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Call to a member function withRequest() on null | Error thrown in file /var/www/html/packages/headless/Classes/Middleware/PageRendererJavaScriptResponseMiddleware.php in line 57. Requested URL: https://api.typo3.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(359,1774899915,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Too few arguments to function FriendsOfTYPO3\\Headless\\Event\\Listener\\AfterCacheableContentIsGeneratedListener::__construct(), 4 passed in /var/www/html/vendor/typo3/cms-core/Classes/Utility/GeneralUtility.php on line 2863 and exactly 5 expected | ArgumentCountError thrown in file /var/www/html/packages/headless/Classes/Event/Listener/AfterCacheableContentIsGeneratedListener.php in line 30. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(360,1774900970,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Too few arguments to function FriendsOfTYPO3\\Headless\\Middleware\\UserIntMiddleware::__construct(), 3 passed in /var/www/html/vendor/typo3/cms-core/Classes/Utility/GeneralUtility.php on line 2863 and exactly 4 expected | ArgumentCountError thrown in file /var/www/html/packages/headless/Classes/Middleware/UserIntMiddleware.php in line 29. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(361,1774902033,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(362,1774902033,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(363,1774902034,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(364,1774902034,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(365,1774902034,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(366,1774902034,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(367,1774902045,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(368,1774902070,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(369,1774902110,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(370,1774902110,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(371,1774902110,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(372,1774902110,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(373,1774902110,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(374,1774902110,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(375,1774902114,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Typed property TYPO3\\CMS\\Core\\Page\\JavaScriptModuleInstruction::$exportName must not be accessed before initialization | Error thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Page/JavaScriptModuleInstruction.php in line 82. Requested URL: https://api.typo3.ddev.site/?type=834',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(376,1774943062,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(377,1774943069,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(378,1774943074,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(379,1774943074,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(380,1774943074,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(381,1774943074,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(382,1774943459,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(383,1774943459,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(384,1774943459,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(385,1774943459,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(386,1774943461,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(387,1774943461,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(388,1774943461,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(389,1774943461,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(390,1774943462,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=694f4930eb3c2ef5afb94b0699bd19ca5e231e2295ad82ba882277a31ab02068',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(391,1774943462,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=694f4930eb3c2ef5afb94b0699bd19ca5e231e2295ad82ba882277a31ab02068',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(392,1774943462,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=694f4930eb3c2ef5afb94b0699bd19ca5e231e2295ad82ba882277a31ab02068',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(393,1774943462,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=694f4930eb3c2ef5afb94b0699bd19ca5e231e2295ad82ba882277a31ab02068',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(394,1774943464,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(395,1774943464,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(396,1774943464,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(397,1774943464,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(398,1774944153,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(399,1774944153,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(400,1774944153,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(401,1774944153,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(402,1774944354,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(403,1774944354,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(404,1774944354,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(405,1774944354,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(406,1774944425,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(407,1774944425,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(408,1774944425,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(409,1774944425,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(410,1774944598,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(411,1774944598,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(412,1774944598,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(413,1774944598,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(414,1774944622,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(415,1774944622,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(416,1774944622,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(417,1774944622,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(418,1774944687,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(419,1774944687,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(420,1774944687,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(421,1774944687,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(422,1774945578,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(423,1774946257,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(424,1774946269,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(425,1774954455,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(426,1774954455,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(427,1774954455,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(428,1774954455,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(429,1774954456,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(430,1774954456,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #8725323237: No $GLOBALS[\'BE_USER\'] available | TYPO3\\CMS\\Core\\Error\\Http\\UnauthorizedException thrown in file /var/www/html/packages/visual-editor/Classes/Middleware/PersistenceMiddleware.php in line 115. Requested URL: https://api.typo3.ddev.site/?type=834&editMode=1&cHash=7884d5fa6ab812a74cefad73f461354eb6f31c626e566858aac588a7627e7e1b',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(431,1774954464,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(432,1774954472,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(433,1774954488,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(434,1774954533,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(435,1774959423,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"9\"}',1,0,'',0,'','info',NULL,NULL),
(436,1774959426,1,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"10\"}',1,0,'',0,'','info',NULL,NULL),
(437,1774959435,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"11\"}',1,0,'',0,'','info',NULL,NULL),
(438,1774959447,1,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"12\"}',1,0,'',0,'','info',NULL,NULL),
(439,1774959448,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\HtmlSanitizer\\Sanitizer::sanitize(): Argument #1 ($html) must be of type string, null given, called in /var/www/html/vendor/typo3/cms-backend/Classes/Preview/RecordFieldPreviewProcessor.php on line 128 | TypeError thrown in file /var/www/html/vendor/typo3/html-sanitizer/src/Sanitizer.php in line 95. Requested URL: https://api.typo3.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--46fea195268f7dc4ae24843f&id=1&',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(440,1774959454,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\HtmlSanitizer\\Sanitizer::sanitize(): Argument #1 ($html) must be of type string, null given, called in /var/www/html/vendor/typo3/cms-backend/Classes/Preview/RecordFieldPreviewProcessor.php on line 128 | TypeError thrown in file /var/www/html/vendor/typo3/html-sanitizer/src/Sanitizer.php in line 95. Requested URL: https://api.typo3.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--46fea195268f7dc4ae24843f&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(441,1774959457,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\HtmlSanitizer\\Sanitizer::sanitize(): Argument #1 ($html) must be of type string, null given, called in /var/www/html/vendor/typo3/cms-backend/Classes/Preview/RecordFieldPreviewProcessor.php on line 128 | TypeError thrown in file /var/www/html/vendor/typo3/html-sanitizer/src/Sanitizer.php in line 95. Requested URL: https://api.typo3.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--46fea195268f7dc4ae24843f&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(442,1774959478,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(443,1774959480,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\HtmlSanitizer\\Sanitizer::sanitize(): Argument #1 ($html) must be of type string, null given, called in /var/www/html/vendor/typo3/cms-backend/Classes/Preview/RecordFieldPreviewProcessor.php on line 128 | TypeError thrown in file /var/www/html/vendor/typo3/html-sanitizer/src/Sanitizer.php in line 95. Requested URL: https://api.typo3.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--46fea195268f7dc4ae24843f&id=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(444,1774959581,1,3,3,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(445,1774959581,1,3,3,'pages',0,0,'Record pages:{uid} was deleted',1,'content','172.18.0.5','{\"uid\":3}',1,0,'',0,'','info',NULL,NULL),
(446,1774959659,1,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"15\"}',1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(7,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(9,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Setup\\Upgrades\\UserSettingsMigration','i:1;'),
(12,'core','formProtectionSessionToken:1','s:64:\"5b9282f41b5825763bf91e4ae057e837c8484ceae0eca7c1696c5abf3293182b\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_themecamino_list_elements` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_themecamino_link` text NOT NULL DEFAULT '',
  `tx_themecamino_link_label` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_link_config` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_link_icon` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_header_style` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1774959659,1774688395,0,0,0,0,'',0,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\" rel=\"noreferrer\">TYPO3</a> and headless.</p>\r\n\r\n',0,0,NULL,NULL,0,0,0,0,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0,0,'','','','',0),
(2,2,1774690231,1774689559,0,0,0,0,'',512,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website test',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\" rel=\"noreferrer\">TYPO3</a> and the Camino Theme.</p>\r\n\r\n',0,0,NULL,NULL,0,0,0,0,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(3,3,1774959581,1774689743,1,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"image_zoom\":\"\",\"imageborder\":\"\",\"imagecols\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagewidth\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_themecamino_header_style\":\"\"}',0,0,0,0,'default',0,NULL,0,'textpic',0,0,'','',0,'Test',0,'','','Test','<p>Test</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','','',0),
(4,2,1774690178,1774690178,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"image\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',2,NULL,0,'camino_hero',0,0,'','',0,'Test',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(5,1,1774959447,1774816817,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Content Element Text',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','','',0),
(6,1,1774959426,1774826358,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'header',0,0,'','',0,'Content Element Header Only',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','','',0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_themecamino_list_item`
--

DROP TABLE IF EXISTS `tx_themecamino_list_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_themecamino_list_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  `category` varchar(50) NOT NULL DEFAULT '',
  `date` bigint(20) DEFAULT NULL,
  `header` varchar(255) NOT NULL DEFAULT '',
  `images` int(10) unsigned NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `link_config` varchar(255) NOT NULL DEFAULT '',
  `link_icon` varchar(255) NOT NULL DEFAULT '',
  `link_label` varchar(255) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_themecamino_list_item`
--

LOCK TABLES `tx_themecamino_list_item` WRITE;
/*!40000 ALTER TABLE `tx_themecamino_list_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_themecamino_list_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-31 15:52:47
